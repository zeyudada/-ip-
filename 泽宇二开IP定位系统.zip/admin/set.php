<?php if (!isset($_SESSION['wuju'])) {exit();}?>
<div class="container">
<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">设置</h3>
  </div>
  <div class="panel-body">
    <input type="text" class="form-control" id="user" placeholder="管理员账号" value="<?=$data['user']?>"><br>
    <input type="text" class="form-control" id="pass" placeholder="管理员密码">
    <label for="name">主页显示的网址（你可以自行替换index文件里的html模板</label>
    <input type="text" class="form-control" id="url" placeholder="模拟网址" value="<?=$data['url']?>">
    <div class="form-group">
      <label for="name">定位接口(可更换 如果使用二开作者的网址请填写moren)</label>
      <input type="text" class="form-control" id="sj" placeholder="定位接口" value="<?=$data['sj']?>">
    </div>
    <input type="text" class="form-control" id="name" placeholder="站长名称" value="<?=$data['name']?>">
    <div class="form-group">
      <label for="name">自定义首页标题</label>
      <input type="text" class="form-control" id="title" placeholder="站长名称" value="<?=$data['title']?>">
    </div>
    <center><button type="button" id="ok" class="btn btn-primary" id="ok">保存</button>
  </div>
</div>
</div>
<script>
$("#ok").click(function(){
  //判断一下下
    $.post("./index.php?set=1",
    {
        user: $("#user").val(),
        pwd: $("#pass").val(),
        url: $("#url").val(),
        sj: $("#sj").val(),
        name: $("#name").val(),
        title: $("#title").val()
    },
    function(data,status){
        if (data == 0) {
          layer.alert("<center><img src='../assets/layer/2.gif'><br>修改失败！</center>");
        }else{
          layer.alert("<center><img src='../assets/layer/1.gif'><br>修改成功！</center>");
        }
    });
});
</script>
</body>
</html>