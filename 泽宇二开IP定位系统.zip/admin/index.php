<?php
include 'common.php';

if (!isset($_SESSION['wuju'])) {

	header('Location: ./login.php');
}

//退出登录
if (isset($_GET['tui'])) {
	session_destroy();
	header('Location: ./login.php');
}

if (!isset($_SESSION['wuju'])) {exit();}
//修改后台配置
if (isset($_GET['set'])) {
	$user = $_POST['user'];$pwd = md5($_POST['pwd']);$url = $_POST['url'];$sj = $_POST['sj'];$name = $_POST['name'];$title = $_POST['title'];
	if ($_POST['pwd'] == '') {$x = DB::query("UPDATE ip_config SET user = '$user',url = '$url',sj = '$sj',name = '$name',title = '$title' WHERE Id = 1");
	}else{$x = DB::query("UPDATE ip_config SET user = '$user',pwd = '$pwd',url = '$url',sj = '$sj',name = '$name',title = '$title' WHERE Id = 1");}
	if ($x) {
		echo 1;
	}else{
		echo 0;
	}
	exit();
}

include 'head.php';
if (isset($_GET['s'])) {
	switch ($_GET['s']) {
		case 'list':
			include 'list.php';
			break;
		case 'set':
			include 'set.php';
			break;
		case 'see':
			include 'see.php';
			break;
		default:
			include 'wuju.php';
			break;
	}
}else{
		include 'wuju.php';
}
?>
</body>
</html>