<?php if (!isset($_SESSION['wuju'])) {exit();}?>
<div class="container">
      <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">后台管理首页</h3></div>
          <ul class="list-group">
			<li class="list-group-item"> <b>数据数量：</b> <b><?=$s?></b></li>
            <li class="list-group-item"> <b>现在时间：</b> <b><?=date('Y-m-d h:i:s')?></b></li>
            <li class="list-group-item"> <b>使用必看：</b> <b>请自行对域名进行防红措施</b></li>
			<li class="list-group-item"> <a href="../" class="btn btn-xs btn-info">返回首页</a>&nbsp;<a href="./?s=set" class="btn btn-xs btn-info">系统设置</a>
			</li>
          </ul>
      </div>
<div class="panel panel-info">
	<div class="panel-heading">
		<h3 class="panel-title">服务器信息</h3>
	</div>
	<ul class="list-group">
		<li class="list-group-item">
			<b>PHP 版本：</b><?php echo phpversion() ?>
			<?php if(ini_get('safe_mode')) { echo '线程安全'; } else { echo '非线程安全'; } ?>
		</li>
		<li class="list-group-item">
			<b>服务器软件：</b><?php echo $_SERVER['SERVER_SOFTWARE'] ?>
		</li>
		<li class="list-group-item">
			<b>系统名称：</b>IP定位系统二开优化版
		</li>
		<li class="list-group-item">
			<?=base64_decode('PGI+5Y6f5L2c6ICFUVHvvJo8L2I+MTY5MTk1NDYyMjxicj48Yj48YSB0YXJnZXQ9Il9ibGFuayIgaHJlZj0iaHR0cDovL3pleXVkYWRhLmNuIj7kuozlvIDkvZzogIXkuLvpobU8L2E+PC9iPg==')//做下信息处理?>
		</li>
		
	</ul>
</div>
  </div>
</body>
</html>