<?php if (!isset($_SESSION['wuju'])) {exit();}?>
<div class="container">
<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">查看</h3>
  </div>
  <div class="panel-body">
<?php
if ($_GET['id']) {
	$id = $_GET['id'];
	$src = DB::get_row("SELECT info FROM ip_list WHERE Id = '$id'");
	echo $src['info'];
}

?>
  </div>
</div>
</div>
</body>
</html>