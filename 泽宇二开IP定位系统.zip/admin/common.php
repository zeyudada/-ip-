<?php
/**
*	Public name: 最新IP定位系统
*	Public phper: 污橘
*	Public date: 2019/11/23
*/
error_reporting(0);
header("content-type:text/html;charset=utf-8");
session_start();
include '../assets/db.class.php';
include '../config.php';
//连接数据库
DB::connect($dbconfig['host'],$dbconfig['user'],$dbconfig['pwd'],$dbconfig['dbname'],$dbconfig['port']);
//获取数据数量
$s = DB::affected(DB::query("SELECT Id FROM ip_list"));
$data = DB::get_row("SELECT user,pwd,url,sj,name,title FROM ip_config WHERE Id = 1");
//管理员登录
if (isset($_GET['login'])) {
	$user = $_POST['user'];$pwd = md5($_POST['pwd']);
	if ($data['user'] == $user && $data['pwd'] == $pwd) {
		echo 1;
		$_SESSION['wuju'] = $user;
	}else{
		echo 0;
	}
	exit();
}
