<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>后台管理登录</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
.login-page {width: 340px;padding: 8% 0 0;margin: auto;}.form {position: relative;z-index: 1;background: #FFFFFF;border-radius:5px;max-width: 340px;margin: 0 auto 100px;padding: 45px;text-align: center;box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);}.form input {font-family: "Roboto", sans-serif;outline: 0;background: #f2f2f2;width: 100%;border: 0;border-radius:25px;margin: 0 0 15px;padding: 15px;box-sizing: border-box;font-size: 14px;}.form button {font-family: "Roboto", sans-serif;text-transform: uppercase;outline: 0;background: #4CAF50;border-radius:25px;width: 100%;border: 0;padding: 15px;color: #FFFFFF;font-size: 14px;-webkit-transition: all 0.3 ease;transition: all 0.3 ease;cursor: pointer;}.form button:hover,.form button:active,.form button:focus {background: #43A047;}.form .message {margin: 15px 0 0;color: #b3b3b3;font-size: 12px;}.form .message a {color: #4CAF50;text-decoration: none;}.form .register-form {display: none;}body {background: #76b852; /* fallback for old browsers */background: -webkit-linear-gradient(right, #76b852, #8DC26F);background: -moz-linear-gradient(right, #76b852, #8DC26F);background: -o-linear-gradient(right, #76b852, #8DC26F);background: linear-gradient(to left, #76b852, #8DC26F);font-family: "Roboto", sans-serif;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;}
</style>
<body>
<div class="login-page">
    <div class="form">
        <div class="login-form">
            <input type="text" placeholder="用户名" id="user">
            <input type="password" placeholder="密码" id="pass">
            <button id="ok">登录</button>
            <p class="message">版权 &copy; wuju 2019-2020 二开版 by 泽宇大大</p>
        </div>
    </div>
</div>
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/layer/layer.js"></script>
<script>
$("#ok").click(function(){
  //判断一下下
    $.post("./common.php?login=1",
    {
        user: $("#user").val(),
        pwd: $("#pass").val()
    },
    function(data,status){
        if (data == 0) {
          layer.alert("<center><img src='../assets/layer/2.gif'><br>登录失败！</center>");
        }else{
          layer.confirm("<center><img src='../assets/layer/1.gif'><br>登录成功！</center>", {

            btn: ["确定"],
            btn1:function(index,layero) {
              window.location.href="./";
            }
  });
        }
    });
});
</script>
</body>
</html>