<?php if (!isset($_SESSION['wuju'])) {exit();}?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?=$data['name']?>-后台管理</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<script src="../assets/js/jquery.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/layer/layer.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
	<div class="container-fluid"> 
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse"
				data-target="#example-navbar-collapse">
			<span class="sr-only">切换导航</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" style="color: #fff"><?=$data['name']?>IP定位系统</a>
	</div>
	<div class="collapse navbar-collapse" id="example-navbar-collapse">
		<ul class="nav navbar-nav">
			<li id="index"><a href="./">首页</a></li>
			<li id="login"><a href="?s=list&p=1">数据</a></li>
			<li id="set"><a href="?s=set">设置</a></li>
			<li><a href="?tui">退出登陆</a></li>
		</ul>
	</div>
	</div>
</nav><br><br><br>