<?php if (!isset($_SESSION['wuju'])) {exit();}?>
<div class="container">
<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">数据中心</h3><a target="_blank" href="https://www.opengps.cn/Data/IP/ipplus.aspx">IP精准定位</a>
  </div>
  <div class="panel-body">
<h5>共有<?=$s?>条数据</h5>
<div class="table-responsive">
  <table class="table">
    <thead>
      <tr>
        <th>IP</th>
        <th>地址</th>
        <th>时间</th>
        <th>操作</th>
      </tr>
    </thead>
    <tbody>
<?php
//删除数据
if (isset($_GET['id'])) {
  $id = $_GET['id'];
  DB::query("DELETE FROM ip_list WHERE Id = '$id'");
  echo '<script>layer.confirm("删除成功！", {
    btn: ["确定"],
    btn1:function(index,layero)
    {
      window.location.href="./?s=list&page='.$_GET['page'].'";
    }
  });</script>';
}
//判断是否有分页参数
if (!isset($_GET['page'])) {
  header('Location: ?s=list&page=1');
}
//获取数据
$p = ($_GET['page']-1)*10;
$result = DB::query("SELECT Id,ip,`time` FROM ip_list ORDER BY Id DESC limit $p, 10");
  if (DB::affected($result) > 0) {
    // 输出数据
    while($row = DB::fetch($result)) {
      echo '<tr><td>'.htmlspecialchars($row['ip']).'</td><td><a href="?s=see&id='.htmlspecialchars($row['Id']).'" class="btn btn-xs btn-info">查看</a></td><td>'.$row['time'].'</td><td><a href="./?s=list&page='.$_GET['page'].'&id='.$row['Id'].'" class="btn btn-xs btn-danger">删除</a></td></tr>';
    }
  }
$page = $_GET['page'];
?>
    </tbody>
</table>
</div>
<ul class="pagination">
<li><a href="./?s=list&page=1">&laquo;</a></li>
<?php
//四舍五入，循环输出页
$num = round($s/10);
for ($i=1; $i < $num+1; $i++) {
  if ($page == $i) {
    echo '<li class="active"><a href="./?s=list&page='.$i.'">'.$i.'</a></li>';;
  }else{
    echo '<li><a href="./?s=list&page='.$i.'">'.$i.'</a></li>';
  }
}
?>
<li><a href="./?s=list&page=<?=$num?>">&raquo;</a></li>
</ul>
</div>
</div>
</div>

</body>
</html>